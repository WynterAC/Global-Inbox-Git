---
toggle2: 1
toggle1: true
---

```meta-bind
INPUT[toggle(showcase):toggle1]
```

```meta-bind
INPUT[toggle(showcase, onValue(1), offValue(0), defaultValue(1)):toggle2]
```

