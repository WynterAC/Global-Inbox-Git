---
number: 
number2: 123
---

```meta-bind
INPUT[number(showcase):number]
```

```meta-bind
INPUT[number(showcase):number2]
```