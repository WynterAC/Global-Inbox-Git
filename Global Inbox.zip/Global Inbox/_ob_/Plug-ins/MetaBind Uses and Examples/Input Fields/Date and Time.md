---
time: 13:05
date2: 2024-01-22T00:00:00+01:00
date1: 2024-03-07
dateTime: 2024-03-13T15:07
---

### Date
```meta-bind
INPUT[date(showcase):date1]
```

### Date Picker

```meta-bind
INPUT[datePicker(showcase):date2]
```

```meta-bind
INPUT[datePicker(showcase, defaultValue(null)):date3]
```

### Time
```meta-bind
INPUT[time(showcase):time]
```


### Date Time
```meta-bind
INPUT[dateTime(showcase):dateTime]
```