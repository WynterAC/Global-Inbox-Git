---
description: |-
  
  ```ad-summary
  Cnesklafjnklcmn,Inca,mdva
  title: Book Description```
editor: |-
  Application: University of Alberta's App
  Default application created on signup.
  Application ID
  This is the application ID, you should send with each API request.
  3e41febc
  Application Keys
  These are application keys used to authenticate requests.
editor2: |-
  asd

  asd
  asd

  as
  d
  asd
  as
  d
  as
  da
  sd

  asd

  as
  d
  as
  d
  as
  d
  as
  d
  as
  d
  a
  d
  as
  d
  as
  dasda
  \\asd
  as
  d
  a
  da
  s
  da
  sd
  a
  d
  a
  sd
  a
  sd

  asd

  asd
---

```ad-summary
title: Book Description


```


```meta-bind
INPUT[editor(showcase):editor]
```

```meta-bind
INPUT[editor(showcase):editor2]
```
 
```meta-bind
INPUT[editor(showcase):description]
```