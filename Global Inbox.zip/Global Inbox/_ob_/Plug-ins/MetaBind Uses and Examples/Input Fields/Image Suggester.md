---
image: Other/Images/img_flower.webp
---

```meta-bind
INPUT[imageSuggester(optionQuery("Other/Images"), showcase):image]
```