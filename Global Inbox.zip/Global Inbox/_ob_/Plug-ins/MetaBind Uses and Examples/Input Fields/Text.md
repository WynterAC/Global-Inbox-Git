---
text: alnsdksdnfknfnjksdbfhj
textArea: textArea
---

### Text

```meta-bind
INPUT[text(showcase):text]
```

```meta-bind
INPUT[text(showcase, limit(10)):text]
```

### Text Area

```meta-bind
INPUT[textArea(showcase, class(meta-bind-full-width), class(meta-bind-high)):textArea]
```
