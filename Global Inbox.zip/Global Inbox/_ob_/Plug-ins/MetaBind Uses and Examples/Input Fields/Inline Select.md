---
select: b
selectproperty: fmtext
propertyname: resultb
---

```meta-bind
INPUT[inlineSelect(option(a), option(b), showcase):select]
```


```meta-bind
INPUT[inlineSelect(option(frontmattertext, inlineop), option(fmtext, inlineop), showcase):selectproperty]
```

```meta-bind
INPUT[inlineSelect(option(frontmattertext,inlineoption), option(frontmattertext,inlineoption), showcase):propertyname]
```

```meta-bind
INPUT[inlineSelect(option(frontmattertext,inlineoption), option(frontmattertext,inlineoption), showcase):propertyname]
```
[[_MB In-line Select]]