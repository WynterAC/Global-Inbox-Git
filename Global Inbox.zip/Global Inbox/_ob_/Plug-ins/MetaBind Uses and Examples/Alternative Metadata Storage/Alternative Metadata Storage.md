
These two inputs are bound to a global in memory cache.

`INPUT[text:globalMemory^test]`

`INPUT[text:globalMemory^test]`

`VIEW[{globalMemory^test123}456][text]`

These two inputs are bound to a per file in memory cache.

`INPUT[text:memory^test]`

`INPUT[text:memory^test]`