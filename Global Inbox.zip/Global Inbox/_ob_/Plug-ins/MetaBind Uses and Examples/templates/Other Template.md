This comes from [[Other Template]].

```meta-bind
INPUT[select(option(a), option(b)):select]
```