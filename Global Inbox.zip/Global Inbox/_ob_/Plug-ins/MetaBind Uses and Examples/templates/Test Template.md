This comes from [[Test Template]].

Completed: `INPUT[toggle:completed]`

[[Test Template]] embeds [[Other Template]].

```meta-bind-embed
[[Other Template]]
```