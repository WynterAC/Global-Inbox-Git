---
tags: example-note
---

This is an example note with an image.

![[img_flower.webp]]