---
tags: example-note
---

This is an example note with callouts.

>[!INFO]
>This is an info.

>[!Danger]
>This is danerous.