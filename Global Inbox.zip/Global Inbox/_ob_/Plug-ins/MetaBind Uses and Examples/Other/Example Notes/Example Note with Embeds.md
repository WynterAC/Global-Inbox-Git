---
tags: example-note
---

This is an example note with embeds.

![[Example Note with Callouts]]

![[Example Note with Image]]