
```meta-bind-button
label: Insert Text
hidden: false
class: ""
tooltip: ""
id: ""
style: default
action:
  type: "replaceSelf"
  replacement: "templates/templater/Templater Template.md"
  templater: true
```

```meta-bind-button
label: Insert Text
hidden: false
class: ""
tooltip: ""
id: ""
style: default
action:
  type: "replaceSelf"
  replacement: "[[Templater Template]]"
  templater: true
```