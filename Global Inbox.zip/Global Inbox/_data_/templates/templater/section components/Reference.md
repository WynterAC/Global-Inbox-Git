See Also:
- <%tp.file.cursor(0)%>