---
tags: type/note
aliases: 
created: {{date}}, {{time}}
modified: {{date}}, {{time}}
template-type: Frontmatter
template-version: "1.7"
---