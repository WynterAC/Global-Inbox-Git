# {{newTitle}}

Text originally in [[{{fromTitle}}]]
**Created:** [[{{date}}]]

{{content}}


