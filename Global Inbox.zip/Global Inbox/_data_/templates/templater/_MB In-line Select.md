


```meta-bind
INPUT[inlineSelect(option(frontmattertext,inlineoptionA), option(frontmattertext,inlineoptionb), showcase):inlineSelect]
```