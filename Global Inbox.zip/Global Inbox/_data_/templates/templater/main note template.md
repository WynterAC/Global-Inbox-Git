Tags:
Associations: 
When: [[<% tp.file.creation_date(format="YYYY-MM-DD") %>]]

## Note:

