---
created: <% tp.date.now("YYYY-MM-DD") %>
---

```
<% tp.date.now("YYYY-MM-DD") %>
```
