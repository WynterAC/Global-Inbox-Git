---
tags: type/book
# type/ theme/ index/ source/ target/ 
# chart/ kanban/ role/ structure/ tool/ visual/ 
# -> https://forum.obsidian.md/t/how-to-use-tags/
aliases: 
title: 
subtitle: 
author: 
authors: 
category: 
publisher: 
publish_date: 
total_page: 
isbn: 
cover_url: 
cover_small_url: 
isbn13: 
isbn10: 
description:
link: 
preview_link: 
rating: 
date:
read: 
status: undefined
# status: backlog, to read, reading, completed, stopped
created: 2022-12-07, 21:45
modified: 2023-03-21, 17:42
# -> https://github.com/beaussan/update-time-on-edit-obsidian
template-type: Frontmatter Book
template-version: "1.2"
cc: "CC BY-SA 4.0"
# -> https://creativecommons.org/licenses/by-sa/4.0/legalcode
source: https://github.com/groepl/Obsidian-Templates
---






