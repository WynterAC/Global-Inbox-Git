---
tags: type/note
# --- Learn more about "How to use tags": https://forum.obsidian.md/t/how-to-use-tags/
aliases:
lead: Lead paragraph goes here
visual: "![[image.jpg]]"
# --- Install plugin: https://github.com/blacksmithgu/obsidian-dataview
created: {{date}}, {{time}}
modified: {{date}}, {{time}}
# --- Install plugin: https://github.com/beaussan/update-time-on-edit-obsidian
template-type: Note
template-version: "1.7"
# --- Find latest updates: https://github.com/groepl/Obsidian-Templates
---

# {{Title}}

<!-- Main content of my thoughts really -->

> [!Note]
> `= this.lead`

---
## Questions
<!-- What remains for you to consider? --> 
- 

## Terms
<!-- Links to definition pages -->
- 

## References
<!-- Links to pages not referenced in the content -->
- 