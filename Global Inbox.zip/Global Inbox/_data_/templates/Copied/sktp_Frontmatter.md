---
tags: type/note
# type/ theme/ index/ source/ target/ 
# chart/ kanban/ role/ structure/ tool/ visual/ 
# -> https://forum.obsidian.md/t/how-to-use-tags/
aliases: 
created: {{date}}, {{time}}
modified: {{date}}, {{time}}
# -> https://github.com/beaussan/update-time-on-edit-obsidian
template-type: Frontmatter
template-version: "1.3"
cc: "CC BY-SA 4.0"
# -> https://creativecommons.org/licenses/by-sa/4.0/legalcode
source: https://github.com/groepl/Obsidian-Templates
---