---
tags: type/book
# --- Learn more about "How to use tags": https://forum.obsidian.md/t/how-to-use-tags/
aliases: 
lead: 
# --- Install plugin: https://github.com/blacksmithgu/obsidian-dataview
title: 
subtitle: 
author: 
authors: 
category: 
publisher: 
publish_date: 
total_page: 
isbn: 
cover_url: 
cover_small_url: 
isbn13: 
isbn10: 
description:
link: 
preview_link: 
rating: 
date:
read: 
status: undefined
# status: backlog, to read, reading, completed, stopped
created: {{date}}, {{time}}
modified: {{date}}, {{time}}
# --- Install plugin: https://github.com/beaussan/update-time-on-edit-obsidian
template-type: Frontmatter Book
template-version: "1.3"
# --- Find latest updates: https://github.com/groepl/Obsidian-Templates
---






