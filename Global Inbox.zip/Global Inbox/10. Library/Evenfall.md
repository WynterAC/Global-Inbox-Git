---
tag: Book
title: "Evenfall"
subtitle: "Director's Cut"
author: [Ais, Santino Hassell]
category: [Assassins]
publisher: 
publish: 2014
total: 0
isbn:  OCLC:1112219019
cover: 
localCover: 
status: unread
created: 2024-08-15 13:33:12
updated: 2024-08-15 13:33:12
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Evenfall