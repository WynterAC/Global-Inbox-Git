---
tag: Book
title: "American Family"
subtitle: "A Novel"
author: [Catherine Marshall-Smith]
category: [Fiction]
publisher: Simon and Schuster
publish: 2017-06-13
total: 399
isbn: 1631521640 9781631521645
cover: http://books.google.com/books/content?id=ndnQDgAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 00:28:32
updated: 2024-08-15 00:28:32
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=ndnQDgAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# American Family