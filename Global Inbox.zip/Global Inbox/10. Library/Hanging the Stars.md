---
tag: Book
title: "Hanging the Stars"
subtitle: ""
author: [Rhys Ford]
category: [Attempted assassination]
publisher: Half Moon Bay
publish: 2016-12-05
total: 0
isbn: 1634778979 9781634778978
cover: http://books.google.com/books/content?id=oaT7MAAACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-14 23:57:03
updated: 2024-08-14 23:57:03
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=oaT7MAAACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Hanging the Stars