---
tag: Book
title: "Murphy's Law"
subtitle: ""
author: [Riley Hart]
category: []
publisher: 
publish: 2020-04-19
total: 358
isbn:  9798638525330
cover: http://books.google.com/books/content?id=xUZ_zQEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:51:44
updated: 2024-08-15 13:51:44
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=xUZ_zQEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Murphy's Law