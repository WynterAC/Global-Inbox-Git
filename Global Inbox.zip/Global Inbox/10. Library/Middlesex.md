---
tag: Book
title: "Middlesex"
subtitle: ""
author: [Jeffrey Eugenides]
category: [Fiction]
publisher: Vintage Canada
publish: 2011-07-18
total: 546
isbn: 0307401944 9780307401946
cover: http://books.google.com/books/content?id=rUHHbYhlIxYC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 00:03:20
updated: 2024-08-15 00:03:20
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Middlesex