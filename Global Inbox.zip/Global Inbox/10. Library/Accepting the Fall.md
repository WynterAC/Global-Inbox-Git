---
tag: Book
title: "Accepting the Fall"
subtitle: ""
author: [Meg Harding]
category: []
publisher: 
publish: 2017-05-09
total: 286
isbn: 1546600647 9781546600640
cover: 
localCover: 
status: unread
created: 2024-08-14 23:58:16
updated: 2024-08-14 23:58:16
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Accepting the Fall