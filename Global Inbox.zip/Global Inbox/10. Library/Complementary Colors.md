---
tag: Book
title: "Complementary Colors"
subtitle: ""
author: [Adrienne Wilder]
category: []
publisher: CreateSpace
publish: 2014-08-24
total: 360
isbn: 1500941557 9781500941550
cover: http://books.google.com/books/content?id=e23YoQEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 01:06:14
updated: 2024-08-15 01:06:14
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Complementary Colors