---
tag: Book
title: "Jumping Jude: Made Marian Series Book 3"
subtitle: ""
author: [Lucy Lennox]
category: [Fiction]
publisher: Made Marian
publish: 2021-02-10
total: 262
isbn: 1954857020 9781954857025
cover: http://books.google.com/books/content?id=Qbc8zgEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:50:13
updated: 2024-08-15 13:50:13
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=Qbc8zgEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Jumping Jude: Made Marian Series Book 3