---
tag: Book
title: "As Meat Loves Salt"
subtitle: ""
author: [Maria McCann]
category: [Fiction]
publisher: HarperCollins UK
publish: 2011-04-28
total: 548
isbn: 0007394446 9780007394449
cover: http://books.google.com/books/content?id=dhyHx_y-XWoC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:31:18
updated: 2024-08-15 13:31:18
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# As Meat Loves Salt