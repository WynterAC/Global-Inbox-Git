---
tag: Book
title: "Return on Investment"
subtitle: ""
author: [Aleksandr Voinov]
category: [Financial institutions]
publisher: Createspace Independent Publishing Platform
publish: 2014-08-22
total: 0
isbn: 1500851841 9781500851842
cover: http://books.google.com/books/content?id=bwTgoQEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 01:15:42
updated: 2024-08-15 01:15:42
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=bwTgoQEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Return on Investment