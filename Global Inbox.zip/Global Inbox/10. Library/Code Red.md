---
tag: Book
title: "Code Red"
subtitle: ""
author: [N. R. Walker]
category: []
publisher: Blueheart Press
publish: 2021-06-16
total: 404
isbn: 1925886638 9781925886634
cover: http://books.google.com/books/content?id=JEh9zgEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:47:46
updated: 2024-08-15 13:47:46
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Code Red