---
tag: Book
title: "Broken Pieces"
subtitle: ""
author: [Riley Hart]
category: [Erotic stories]
publisher: Createspace Independent Publishing Platform
publish: 2014-02-03
total: 442
isbn: 1495458881 9781495458880
cover: http://books.google.com/books/content?id=r0EBoQEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 01:08:25
updated: 2024-08-15 01:08:25
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Broken Pieces