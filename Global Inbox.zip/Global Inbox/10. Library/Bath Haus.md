---
tag: Book
title: "Bath Haus"
subtitle: "A Thriller"
author: [P. J. Vernon]
category: [Fiction]
publisher: Anchor
publish: 2022-05-24
total: 321
isbn: 0593311310 9780593311318
cover: http://books.google.com/books/content?id=fwxuEAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:22:45
updated: 2024-08-15 13:22:45
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=fwxuEAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Bath Haus