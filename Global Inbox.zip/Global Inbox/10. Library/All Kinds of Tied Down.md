---
tag: Book
title: "All Kinds of Tied Down"
subtitle: ""
author: [Mary Calmes]
category: [Gay erotic stories]
publisher: Dreamspinner Press LLC
publish: 2014-07-04
total: 0
isbn: 1632160641 9781632160645
cover: http://books.google.com/books/content?id=d7WGoAEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 01:07:16
updated: 2024-08-15 01:07:16
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# All Kinds of Tied Down