---
tag: Book
title: "Just a Bit Twisted"
subtitle: ""
author: [Alessandra Hazard]
category: []
publisher: 
publish: 2014-12-15
total: 158
isbn: 1505321174 9781505321173
cover: 
localCover: 
status: unread
created: 2024-08-15 13:54:24
updated: 2024-08-15 13:54:24
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Just a Bit Twisted