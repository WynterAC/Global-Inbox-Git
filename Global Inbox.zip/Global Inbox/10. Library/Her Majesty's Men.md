---
tag: Book
title: "Her Majesty's Men"
subtitle: ""
author: [Marquesate]
category: []
publisher: Camouflage Press
publish: 2008-11
total: 144
isbn: 0955988004 9780955988004
cover: http://books.google.com/books/content?id=n_twPgAACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:25:40
updated: 2024-08-15 13:25:40
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=n_twPgAACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Her Majesty's Men