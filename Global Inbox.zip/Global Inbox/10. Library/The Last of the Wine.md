---
tag: Book
title: "The Last of the Wine"
subtitle: ""
author: [Mary Renault]
category: [Fiction]
publisher: 
publish: 1956
total: 335
isbn: 0450028194 9780450028199
cover: 
localCover: 
status: unread
created: 2024-08-15 13:31:01
updated: 2024-08-15 13:31:01
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# The Last of the Wine