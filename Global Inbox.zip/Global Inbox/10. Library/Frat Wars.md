---
tag: Book
title: "Frat Wars"
subtitle: "King of Thieves"
author: [Saxon James]
category: [Fiction]
publisher: May Books
publish: 2021-10-25
total: 276
isbn: 1922741000 9781922741004
cover: http://books.google.com/books/content?id=WOyzzgEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 01:06:01
updated: 2024-08-15 01:06:01
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=WOyzzgEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Frat Wars