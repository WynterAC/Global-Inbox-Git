---
tag: Book
title: "In the Middle of Somewhere"
subtitle: ""
author: [Roan Parrish]
category: [Fiction]
publisher: Middle of Somewhere
publish: 2019-06-18
total: 414
isbn: 1949749037 9781949749038
cover: http://books.google.com/books/content?id=rprAxwEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 00:53:58
updated: 2024-08-15 00:53:58
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=rprAxwEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# In the Middle of Somewhere