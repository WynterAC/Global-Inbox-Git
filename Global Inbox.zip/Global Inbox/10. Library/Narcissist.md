---
tag: Book
title: "Narcissist"
subtitle: ""
author: [Suzi Slade]
category: [Fiction]
publisher: Booktango
publish: 2015-12-02
total: 219
isbn: 1468966847 9781468966848
cover: http://books.google.com/books/content?id=HhMgCwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:28:48
updated: 2024-08-15 13:28:48
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=HhMgCwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Narcissist