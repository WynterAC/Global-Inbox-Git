---
tag: Book
title: "Nights Like These"
subtitle: ""
author: [Chris Scully]
category: []
publisher: Dreamspinner Press LLC
publish: 2015-01-26
total: 0
isbn: 1632164000 9781632164001
cover: http://books.google.com/books/content?id=p70JrgEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 00:28:20
updated: 2024-08-15 00:28:20
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=p70JrgEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Nights Like These