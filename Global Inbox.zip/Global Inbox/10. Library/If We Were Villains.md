---
tag: Book
title: "If We Were Villains"
subtitle: "A Novel"
author: [M. L. Rio]
category: [Fiction]
publisher: Flatiron Books
publish: 2017-04-11
total: 368
isbn: 1250095301 9781250095305
cover: http://books.google.com/books/content?id=negZDQAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 00:46:29
updated: 2024-08-15 00:46:29
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=negZDQAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# If We Were Villains