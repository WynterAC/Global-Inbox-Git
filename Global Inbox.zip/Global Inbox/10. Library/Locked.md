---
tag: Book
title: "Locked"
subtitle: ""
author: [Brooke Blaine, Ella Frank]
category: [Gay men]
publisher: Independently Published
publish: 2018-11-11
total: 378
isbn: 1731189273 9781731189271
cover: http://books.google.com/books/content?id=w_1ZvgEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:50:50
updated: 2024-08-15 13:50:50
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Locked