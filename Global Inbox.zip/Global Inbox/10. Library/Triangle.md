---
tag: Book
title: "Triangle"
subtitle: "The Complete Series"
author: [Susann Julieva, Romelle Engel]
category: [Fiction]
publisher: Createspace Independent Pub
publish: 2013-06-05
total: 374
isbn: 1489556311 9781489556318
cover: http://books.google.com/books/content?id=z01MnQEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:25:02
updated: 2024-08-15 13:25:02
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=z01MnQEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Triangle