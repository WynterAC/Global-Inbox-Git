---
tag: Book
title: "Test Drive"
subtitle: ""
author: [Riley Hart]
category: [Gay men]
publisher: Createspace Independent Publishing Platform
publish: 2016-05-30
total: 0
isbn: 1533339619 9781533339614
cover: http://books.google.com/books/content?id=nncGDQEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:52:07
updated: 2024-08-15 13:52:07
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=nncGDQEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Test Drive