---
tag: Book
title: "Southernmost"
subtitle: ""
author: [Silas House]
category: [Fiction]
publisher: Algonquin Books
publish: 2019-06-04
total: 369
isbn: 1616209364 9781616209360
cover: http://books.google.com/books/content?id=vxB1DwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-14 23:54:47
updated: 2024-08-14 23:54:47
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=vxB1DwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Southernmost