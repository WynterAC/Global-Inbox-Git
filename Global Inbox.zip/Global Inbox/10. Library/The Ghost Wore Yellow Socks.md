---
tag: Book
title: "The Ghost Wore Yellow Socks"
subtitle: ""
author: [Josh Lanyon]
category: [Fiction]
publisher: JustJoshin , Publishing, Inc.
publish: 2011-12-16
total: 
isbn: 0984766979 9780984766970
cover: http://books.google.com/books/content?id=If8_EAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 00:02:55
updated: 2024-08-15 00:02:55
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=If8_EAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# The Ghost Wore Yellow Socks