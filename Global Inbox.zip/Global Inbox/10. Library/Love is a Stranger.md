---
tag: Book
title: "Love is a Stranger"
subtitle: ""
author: [John Wiltshire]
category: [Fiction]
publisher: Decent Fellows Press
publish: 2023-07-28
total: 361
isbn: 3757950046 9783757950040
cover: http://books.google.com/books/content?id=SrbNEAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:41:26
updated: 2024-08-15 13:41:26
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=SrbNEAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Love is a Stranger