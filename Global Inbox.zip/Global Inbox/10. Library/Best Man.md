---
tag: Book
title: "Best Man"
subtitle: ""
author: [Lily Morton]
category: []
publisher: 
publish: 2019-10-10
total: 232
isbn: 1693882795 9781693882791
cover: http://books.google.com/books/content?id=O5TZywEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 01:15:57
updated: 2024-08-15 01:15:57
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=O5TZywEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Best Man