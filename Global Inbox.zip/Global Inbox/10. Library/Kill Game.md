---
tag: Book
title: "Kill Game"
subtitle: ""
author: [Cordelia Kingsbridge]
category: [Fiction]
publisher: Riptide Publishing
publish: 2017-10-23
total: 304
isbn: 1626496196 9781626496194
cover: http://books.google.com/books/content?id=d1BkEAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 01:11:53
updated: 2024-08-15 01:11:53
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Kill Game