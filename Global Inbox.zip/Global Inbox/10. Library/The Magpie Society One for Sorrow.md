---
tag: Book
title: "The Magpie Society: One for Sorrow"
subtitle: ""
author: [Amy McCulloch, Zoe Sugg]
category: [Juvenile Fiction]
publisher: Penguin UK
publish: 2020-10-29
total: 336
isbn: 0241402360 9780241402368
cover: http://books.google.com/books/content?id=vVLODwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:43:49
updated: 2024-08-15 13:43:49
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# The Magpie Society: One for Sorrow