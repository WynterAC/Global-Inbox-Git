---
tag: Book
title: "The Dove in the Belly"
subtitle: ""
author: [Jim Grimsley]
category: [Young Adult Fiction]
publisher: Chronicle Books
publish: 2022-05-03
total: 340
isbn: 1646141490 9781646141494
cover: http://books.google.com/books/content?id=wGJVEAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 00:42:45
updated: 2024-08-15 00:42:45
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# The Dove in the Belly