---
tag: Book
title: "Gone Girl"
subtitle: "A Novel"
author: [Gillian Flynn]
category: [Fiction]
publisher: Ballantine Books
publish: 2012-06-05
total: 497
isbn: 0307588386 9780307588388
cover: http://books.google.com/books/content?id=L25K1tY5WyoC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 00:48:06
updated: 2024-08-15 00:48:06
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=L25K1tY5WyoC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Gone Girl