---
tag: Book
title: "The Mermaid Murders"
subtitle: "The Art of Murder 1"
author: [Josh Lanyon]
category: [Fiction]
publisher: Justjoshin Publishing, Incorporated
publish: 2019-03-28
total: 328
isbn: 1945802480 9781945802485
cover: http://books.google.com/books/content?id=serJwwEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:50:32
updated: 2024-08-15 13:50:32
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# The Mermaid Murders