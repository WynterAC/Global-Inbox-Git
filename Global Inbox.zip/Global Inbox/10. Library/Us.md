---
tag: Book
title: "Us"
subtitle: ""
author: [Elle Kennedy, Sarina Bowen]
category: [Fiction]
publisher: Rennie Road Books
publish: 2016-03-08
total: 275
isbn: 1942444125 9781942444121
cover: http://books.google.com/books/content?id=fE1jDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:51:25
updated: 2024-08-15 13:51:25
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=fE1jDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Us