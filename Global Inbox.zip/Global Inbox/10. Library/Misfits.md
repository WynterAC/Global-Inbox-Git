---
tag: Book
title: "Misfits"
subtitle: "Urban Soul"
author: [Garrett Leigh]
category: []
publisher: Createspace Independent Publishing Platform
publish: 2018-03-27
total: 290
isbn: 1986875008 9781986875004
cover: http://books.google.com/books/content?id=cTHKtQEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 00:32:37
updated: 2024-08-15 00:32:37
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=cTHKtQEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Misfits