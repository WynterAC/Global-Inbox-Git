---
tag: Book
title: "Lie With Me"
subtitle: "A Novel"
author: [Philippe Besson]
category: [Fiction]
publisher: Scribner
publish: 2019-04-30
total: 160
isbn: 1501197878 9781501197871
cover: http://books.google.com/books/content?id=rvePDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 01:05:19
updated: 2024-08-15 01:05:19
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Lie With Me