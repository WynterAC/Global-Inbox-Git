---
tag: Book
title: "Beneath the Stain"
subtitle: ""
author: [Amy Lane]
category: [Fiction]
publisher: Beneath the Stain
publish: 2019-08-13
total: 0
isbn: 1641081783 9781641081788
cover: http://books.google.com/books/content?id=7BwBxAEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 01:06:35
updated: 2024-08-15 01:06:35
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=7BwBxAEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Beneath the Stain