---
tag: Book
title: "Less"
subtitle: ""
author: [Andrew Sean Greer]
category: []
publisher: Turtleback
publish: 2019
total: 
isbn: 1663608202 9781663608208
cover: http://books.google.com/books/content?id=eA82zgEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:53:09
updated: 2024-08-15 13:53:09
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=eA82zgEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Less