---
tag: Book
title: "Tied Up in Knots"
subtitle: ""
author: [Mary Calmes]
category: [Gay men]
publisher: Dreamspinner Press LLC
publish: 2016-09-16
total: 0
isbn: 1634777549 9781634777544
cover: http://books.google.com/books/content?id=hiApvgAACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:52:20
updated: 2024-08-15 13:52:20
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=hiApvgAACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Tied Up in Knots