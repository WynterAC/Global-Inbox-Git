---
tag: Book
title: "Tequila Mockingbird"
subtitle: ""
author: [Rhys Ford]
category: [Fiction]
publisher: Dreamspinner Press
publish: 2014-06-27
total: 246
isbn: 1632160145 9781632160140
cover: http://books.google.com/books/content?id=Jdc6BQAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-14 23:56:41
updated: 2024-08-14 23:56:41
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=Jdc6BQAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Tequila Mockingbird