---
tag: Book
title: "The Married Man"
subtitle: "A Novel"
author: [Edmund White]
category: [Fiction]
publisher: Vintage
publish: 2010-09-08
total: 338
isbn: 0307764486 9780307764485
cover: http://books.google.com/books/content?id=M_8OmXiiL9AC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:21:37
updated: 2024-08-15 13:21:37
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=M_8OmXiiL9AC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# The Married Man