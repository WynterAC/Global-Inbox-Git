---
tag: Book
title: "The Freshman"
subtitle: ""
author: [Louise Collins]
category: []
publisher: 
publish: 2018
total: 0
isbn: 1773397982 9781773397986
cover: 
localCover: 
status: unread
created: 2024-08-15 13:39:23
updated: 2024-08-15 13:39:23
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# The Freshman