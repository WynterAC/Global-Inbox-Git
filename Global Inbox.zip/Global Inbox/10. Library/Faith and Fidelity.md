---
tag: Book
title: "Faith and Fidelity"
subtitle: ""
author: [Tere Michaels]
category: [Fiction]
publisher: Faith, Love, & Devotion
publish: 2018-04-24
total: 0
isbn: 1641080868 9781641080866
cover: http://books.google.com/books/content?id=NcgGtAEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 01:08:46
updated: 2024-08-15 01:08:46
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=NcgGtAEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Faith and Fidelity