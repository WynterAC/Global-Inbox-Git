---
tag: Book
title: "Taming the Beast"
subtitle: ""
author: [Andrew Grey]
category: [Fiction]
publisher: Dreamspinner Press LLC
publish: 2017
total: 0
isbn: 1640800050 9781640800052
cover: http://books.google.com/books/content?id=jgXLswEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 00:30:11
updated: 2024-08-15 00:30:11
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=jgXLswEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Taming the Beast