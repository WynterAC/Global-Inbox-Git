---
tag: Book
title: "Lies With Man"
subtitle: ""
author: [Michael Nava]
category: [Fiction]
publisher: Bywater Books
publish: 2021-04-27
total: 305
isbn: 1612941982 9781612941981
cover: http://books.google.com/books/content?id=fBssEAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 00:43:16
updated: 2024-08-15 00:43:16
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=fBssEAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Lies With Man