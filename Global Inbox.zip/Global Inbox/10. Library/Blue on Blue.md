---
tag: Book
title: "Blue on Blue"
subtitle: ""
author: [Dal Maclean]
category: [Electronic books]
publisher: One Block Empire
publish: 2020
total: 0
isbn: 1935560697 9781935560692
cover: 
localCover: 
status: unread
created: 2024-08-15 13:37:21
updated: 2024-08-15 13:37:21
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Blue on Blue