---
tag: Book
title: "Ways and Means"
subtitle: "Lincoln and His Cabinet and the Financing of the Civil War"
author: [Roger Lowenstein]
category: [History]
publisher: Penguin
publish: 2022-03-08
total: 449
isbn: 0735223564 9780735223561
cover: http://books.google.com/books/content?id=cEAyEAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 00:26:16
updated: 2024-08-15 00:26:16
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=cEAyEAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Ways and Means