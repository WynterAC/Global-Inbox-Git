---
tag: Book
title: "Loaded"
subtitle: ""
author: [Christos Tsiolkas]
category: [Fiction]
publisher: Random House
publish: 2011-05-31
total: 161
isbn: 1446476936 9781446476932
cover: http://books.google.com/books/content?id=j1e7Cfj8Vo8C&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:22:06
updated: 2024-08-15 13:22:06
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=j1e7Cfj8Vo8C&printsec=frontcover&img=1&zoom=1&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Loaded