---
tag: Book
title: "What Belongs to You"
subtitle: "A Novel"
author: [Garth Greenwell]
category: [Fiction]
publisher: Farrar, Straus and Giroux
publish: 2016-01-19
total: 209
isbn: 0374713189 9780374713188
cover: http://books.google.com/books/content?id=AkkJCgAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 00:53:05
updated: 2024-08-15 00:53:05
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=AkkJCgAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# What Belongs to You