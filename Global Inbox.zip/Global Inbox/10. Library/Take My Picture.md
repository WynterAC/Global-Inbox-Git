---
tag: Book
title: "Take My Picture"
subtitle: ""
author: [Giselle Ellis]
category: [Fiction]
publisher: Dreamspinner Press
publish: 2010-02-23
total: 155
isbn: 1615813969 9781615813964
cover: http://books.google.com/books/content?id=e1X6XwEZFvMC&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:27:25
updated: 2024-08-15 13:27:25
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=e1X6XwEZFvMC&printsec=frontcover&img=1&zoom=1&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Take My Picture