---
tag: Book
title: "Zero at the Bone"
subtitle: ""
author: [Jane Seville]
category: [Fiction]
publisher: Dreamspinner Press
publish: 2009-04-06
total: 308
isbn: 1935192809 9781935192800
cover: http://books.google.com/books/content?id=GovOQ1qilTQC&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:40:00
updated: 2024-08-15 13:40:00
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=GovOQ1qilTQC&printsec=frontcover&img=1&zoom=1&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Zero at the Bone