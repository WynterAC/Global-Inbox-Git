---
tag: Book
title: "Him"
subtitle: ""
author: [Elle Kennedy, Sarina Bowen]
category: [Fiction]
publisher: Rennie Road Books
publish: 2015-07-28
total: 309
isbn: 1942444079 9781942444077
cover: http://books.google.com/books/content?id=eE1jDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:51:35
updated: 2024-08-15 13:51:35
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=eE1jDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Him