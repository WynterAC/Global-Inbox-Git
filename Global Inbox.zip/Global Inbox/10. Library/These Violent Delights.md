---
tag: Book
title: "These Violent Delights"
subtitle: "A Novel"
author: [Micah Nemerever]
category: [Fiction]
publisher: HarperCollins
publish: 2020-09-15
total: 480
isbn: 0062963651 9780062963659
cover: http://books.google.com/books/content?id=x47CDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-14 22:35:43
updated: 2024-08-14 22:35:43
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=x47CDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# These Violent Delights