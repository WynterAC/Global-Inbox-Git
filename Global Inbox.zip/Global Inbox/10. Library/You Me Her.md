---
tag: Book
title: "You, Me & Her"
subtitle: ""
author: [Tanya Chris]
category: [Fiction]
publisher: TC Publishing
publish: 
total: 290
isbn:  
cover: http://books.google.com/books/content?id=emYYEAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:55:33
updated: 2024-08-15 13:55:33
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=emYYEAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# You, Me & Her