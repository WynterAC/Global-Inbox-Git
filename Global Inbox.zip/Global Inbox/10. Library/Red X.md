---
tag: Book
title: "Red X"
subtitle: "A Novel"
author: [David Demchuk]
category: [Fiction]
publisher: National Geographic Books
publish: 2021-08-31
total: 0
isbn: 0771025017 9780771025013
cover: http://books.google.com/books/content?id=rfqOEAAAQBAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 00:25:56
updated: 2024-08-15 00:25:56
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Red X