---
tag: Book
title: "Can't Hide from Me"
subtitle: ""
author: [Cordelia Kingsbridge]
category: [Fiction]
publisher: Riptide Publishing
publish: 2016-10-03
total: 344
isbn: 1626494436 9781626494435
cover: http://books.google.com/books/content?id=Q1FkEAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 00:26:07
updated: 2024-08-15 00:26:07
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=Q1FkEAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Can't Hide from Me