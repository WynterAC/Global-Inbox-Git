---
tag: Book
title: "The Destroyers"
subtitle: "A Novel"
author: [Christopher Bollen]
category: [Fiction]
publisher: HarperCollins
publish: 2017-06-27
total: 650
isbn: 0062330004 9780062330000
cover: http://books.google.com/books/content?id=x5NnDQAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:20:15
updated: 2024-08-15 13:20:15
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# The Destroyers