---
tag: Book
title: "An Instance of the Fingerpost"
subtitle: "Explore the murky world of 17th-century Oxford in this iconic historical thriller"
author: [Iain Pears]
category: [Fiction]
publisher: Random House
publish: 2011-04-30
total: 704
isbn: 144646623X 9781446466230
cover: http://books.google.com/books/content?id=59IPV0UX_AMC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 00:43:02
updated: 2024-08-15 00:43:02
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# An Instance of the Fingerpost