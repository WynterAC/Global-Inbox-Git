---
tag: Book
title: "Fatal Shadows"
subtitle: "The Adrien English Mysteries 1"
author: [Josh Lanyon]
category: [Fiction]
publisher: JustJoshin Publishing, Inc.
publish: 2021-01-07
total: 202
isbn: 1937909077 9781937909079
cover: http://books.google.com/books/content?id=F7MSEAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:35:13
updated: 2024-08-15 13:35:13
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=F7MSEAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Fatal Shadows