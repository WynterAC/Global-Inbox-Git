---
tag: Book
title: "Battle Royale"
subtitle: ""
author: [Kōshun Takami]
category: [Comics & Graphic Novels]
publisher: Viz Media
publish: 2003
total: 628
isbn: 156931778X 9781569317785
cover: http://books.google.com/books/content?id=1fB8p-dZLSIC&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 00:34:39
updated: 2024-08-15 00:34:39
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Battle Royale