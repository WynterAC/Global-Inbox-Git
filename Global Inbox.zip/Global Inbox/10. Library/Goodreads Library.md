
  

| Title                                                               | Author                      | ISBN       | ISBN13        | Average Rating |
| ------------------------------------------------------------------- | --------------------------- | ---------- | ------------- | -------------- |
| Style of Love (Gay 4 Renovations, #1)                               | A.J. Sherwood               |            |               | 4.08           |
| The Line of Beauty                                                  | Alan Hollinghurst           | 0739464469 | 9780739464465 | 3.75           |
| Call Me By Your Name (Call Me By Your Name, #1)                     | André Aciman                | 1786495252 | 9781786495259 | 4.10           |
| Less Is Lost (Arthur Less #2)                                       | Andrew Sean Greer           | 0316301396 | 9780316301398 | 3.72           |
| Red, White & Royal Blue                                             | Casey McQuiston             |            |               | 4.08           |
| A Single Man                                                        | Christopher Isherwood       | 0816638624 | 9780816638628 | 4.07           |
| Maurice                                                             | E.M. Forster                | 0393310329 | 9780393310320 | 4.08           |
| Try (Temptation, #1)                                                | Ella Frank                  |            |               | 4.15           |
| A Little Life                                                       | Hanya Yanagihara            |            |               | 4.32           |
| Life After Joe                                                      | Harper Fox                  | 1426890362 | 9781426890369 | 3.89           |
| Comfort and Joy                                                     | Jim Grimsley                | 1565123964 | 9781565123960 | 4.05           |
| Always (Always & Forever #1)                                        | Kindle Alexander            |            | 9780989117395 | 4.18           |
| Cut & Run (Cut & Run, #1)                                           | Madeleine Urban             | 193519223X | 9781935192237 | 4.02           |
| The Song of Achilles                                                | Madeline Miller             | 1408816032 | 9781408816035 | 4.32           |
| Tangled Sheets                                                      | Michael Thomas Ford         | 073944915X |               | 3.84           |
| ==Broken==                                                          | Nicola Haken                |            |               | 4.24           |
| Crossroads (Crossroads, #1)                                         | Riley Hart                  |            |               | 4.05           |
| Riven (Riven, #1)                                                   | Roan Parrish                | 1524799327 |               | 4.03           |
| Him (Him, #1)                                                       | Sarina Bowen                | 1942444079 | 9781942444077 | 4.24           |
| If This Gets Out                                                    | Sophie Gonzales             | 1250805805 | 9781250805805 | 3.92           |
| Two Boys Kissing                                                    | David Levithan              | 0307931900 | 9780307931900 | 4.08           |
| What Belongs to You                                                 | Garth Greenwell             | 0374288224 | 9780374288228 | 3.77           |
| Something Like Summer (Something Like, #1)                          | Jay Bell                    |            | 9781458015327 | 4.02           |
| Bear, Otter, and the Kid (Bear, Otter, and the Kid, #1)             | T.J. Klune                  |            |               | 4.18           |
| Le Berceau                                                          | Julius Eks                  |            | 9781635556889 | 3.33           |
| Dearest Milton James                                                | N.R. Walker                 |            |               | 4.46           |
| ==Paint Eater==                                                     | Marina Vivancos             |            |               | 4.14           |
| In the Middle of Somewhere (Middle of Somewhere, #1)                | Roan Parrish                |            | 9781949749021 | 4.16           |
| Helping Hand (Housemates, #1)                                       | Jay Northcote               |            | 9781310322075 | 3.74           |
| Dedicated (Rhythm of Love, #1)                                      | Neve Wilder                 |            |               | 4.12           |
| Lie With Me                                                         | Philippe Besson             | 1501197878 | 9781501197871 | 4.26           |
| These Vile Secrets (Enclave, #1)                                    | C.E. Ricci                  |            | 9798715081469 | 4.18           |
| Don't You Dare                                                      | C.E. Ricci                  |            |               | 4.06           |
| After Rain Falls (River of Rain, #2)                                | C.E. Ricci                  |            |               | 4.16           |
| Where There's a Will (Lost Boys, #1)                                | Jessie  Walker              |            |               | 4.29           |
| Love Is a Stranger (More Heat Than the Sun #1)                      | John  Wiltshire             |            |               | 4.04           |
| You, Me & Her (My Guys Series)                                      | Tanya Chris                 |            |               | 4.18           |
| At Attention (Out of Uniform, #2)                                   | Annabeth Albert             |            |               | 3.98           |
| Where Death Meets the Devil (Death and the Devil, #1)               | L.J. Hayward                | 1626497168 | 9781626497160 | 4.15           |
| Point of No Return (Turning Point, #1)                              | N.R. Walker                 |            |               | 4.03           |
| King of Thieves (Frat Wars, #1)                                     | Saxon James                 |            |               | 4.11           |
| Complementary Colors                                                | Adrienne Wilder             |            |               | 4.24           |
| Just a Bit Wrong (Straight Guys, #4)                                | Alessandra Hazard           |            |               | 4.06           |
| The Locker Room                                                     | Amy Lane                    | 1613720122 | 9781613720127 | 4.12           |
| Beneath the Stain (Beneath the Stain, #1)                           | Amy Lane                    |            | 9781632165107 | 4.41           |
| Find Me (Call Me By Your Name, #2)                                  | André Aciman                | 0374155011 | 9780374155018 | 3.26           |
| Less (Arthur Less, #1)                                              | Andrew Sean Greer           |            |               | 3.63           |
| The Complete Maus                                                   | Art Spiegelman              | 0141014083 | 9780141014081 | 4.57           |
| The Machine Stops                                                   | E.M. Forster                | 140990329X | 9781409903291 | 4.07           |
| Norwegian Wood                                                      | Haruki Murakami             | 0375704027 | 9780375704024 | 4.01           |
| 1Q84 (1Q84, #1-3)                                                   | Haruki Murakami             | 0307593312 | 9780307593313 | 3.97           |
| Chaos: Making a New Science                                         | James Gleick                | 0140092501 | 9780140092509 | 4.03           |
| Blindness                                                           | José Saramago               |            |               | 4.17           |
| The Devotion of Suspect X (Detective Galileo, #1)                   | Keigo Higashino             | 0312375069 | 9780312375065 | 4.17           |
| Why the Devil Stalks Death (Death and the Devil, #2)                | L.J. Hayward                |            | 9780994457189 | 4.33           |
| Borrowing Blue (Made Marian, #1)                                    | Lucy Lennox                 |            |               | 4.23           |
| Neuroscience: Exploring the Brain                                   | Mark F. Bear                | 0781760038 | 9780781760034 | 4.27           |
| Ache                                                                | Marley Valentine            |            |               | 3.96           |
| All Kinds of Tied Down (Marshals, #1)                               | Mary Calmes                 | 163216065X | 9781632160652 | 4.19           |
| A Matter of Time, Vol. 1 (A Matter of Time, #1-2)                   | Mary Calmes                 | 1615815244 | 9781615815241 | 4.26           |
| A Matter of Time Book I (A Matter of Time, #1)                      | Mary Calmes                 | 1897532733 | 9781897532737 | 4.03           |
| Tied Up in Knots (Marshals, #3)                                     | Mary Calmes                 | 1634777557 | 9781634777551 | 4.40           |
| Frankenstein: The 1818 Text                                         | Mary Wollstonecraft Shelley |            |               | 3.87           |
| Cognitive Neuroscience: The Biology of the Mind                     | Michael S. Gazzaniga        | 0393977773 | 9780393977776 | 4.12           |
| Arrows Through Archer                                               | Nash Summers                |            |               | 4.23           |
| Something About Us (Saint and Lucky #2)                             | Riley Hart                  |            |               | 4.08           |
| Endless Stretch of Blue                                             | Riley Hart                  |            |               | 4.23           |
| Test Drive (Crossroads #3)                                          | Riley Hart                  |            |               | 4.14           |
| Stay (Blackcreek, #2)                                               | Riley Hart                  |            |               | 4.17           |
| The Endgame (Atlanta Lightning, #1)                                 | Riley Hart                  |            |               | 4.30           |
| Murphy's Law (Havenwood, #2)                                        | Riley Hart                  |            |               | 4.28           |
| Broken Pieces (Broken Pieces, #1)                                   | Riley Hart                  |            | 1230000215586 | 4.14           |
| Behave: The Biology of Humans at Our Best and Worst                 | Robert M. Sapolsky          | 1594205078 | 9781594205071 | 4.40           |
| Us (Him, #2)                                                        | Sarina Bowen                | 1942444133 | 9781942444138 | 4.28           |
| Faith & Fidelity (Faith, Love, & Devotion, #1)                      | Tere Michaels               | 1596327723 | 9781596327726 | 3.99           |
| Just a Bit Obsessed (Straight Guys, #2)                             | Alessandra Hazard           |            |               | 3.83           |
| Trick Play (Fake Boyfriend, #2)                                     | Eden Finley                 |            |               | 4.13           |
| Boy Shattered                                                       | Eli Easton                  |            |               | 4.35           |
| Robbie (Confessions, #1)                                            | Ella Frank                  |            |               | 4.29           |
| Locked (PresLocke, #2)                                              | Ella Frank                  |            |               | 4.29           |
| Finley (Sunset Cove, #1)                                            | Ella Frank                  |            |               | 4.01           |
| Heart                                                               | Garrett Leigh               | 1632163675 | 9781632163677 | 4.21           |
| The Mermaid Murders (The Art of Murder, #1)                         | Josh Lanyon                 |            | 9781937909826 | 4.18           |
| Jumping Jude (Made Marian, #3)                                      | Lucy Lennox                 |            |               | 4.31           |
| No Quick Fix (Torus Intercession #1)                                | Mary Calmes                 |            |               | 4.19           |
| ==Overexposed (In Focus, #4)==                                      | Megan Erickson              | 1101988614 | 9781101988619 | 4.18           |
| Bossy                                                               | N.R. Walker                 |            |               | 4.21           |
| Pieces of You (Missing Pieces, #1)                                  | N.R. Walker                 |            |               | 4.31           |
| The Murder Between Us (A Noah & Cole Thriller, #1)                  | Tal Bauer                   |            |               | 4.25           |
| Code Red (Atrous, #1)                                               | N.R. Walker                 |            |               | 4.26           |
| Enemies of the State (The Executive Office #1)                      | Tal Bauer                   |            |               | 4.21           |
| These Deviant Ties                                                  | Andi Rhodes                 |            |               | 4.17           |
| Maahes (Malicious Gods: Egypt)                                      | Emma Jaye                   |            |               | 4.20           |
| Obsession of the Egoist (Egoist #2)                                 | Nero Seal                   |            |               | 4.00           |
| Love of the Egoist (Egoist #1)                                      | Nero Seal                   |            |               | 3.92           |
| Iblis’ Affliction (Reapers #1)                                      | Nero Seal                   |            |               | 4.06           |
| Seth (Malicious Gods: Egypt)                                        | Nero Seal                   |            |               | 3.95           |
| Acceptance of the Egoist (Egoist #1.5)                              | Nero Seal                   |            |               | 4.14           |
| Egoist Box Set (1-1.5)                                              | Nero Seal                   |            |               | 4.40           |
| Enemy of My Enemy (Executive Office #2)                             | Tal Bauer                   |            |               | 4.48           |
| The Kidnapping of Roan Sinclair                                     | Ashlyn Drewek               | 1955211000 |               | 4.05           |
| Dig Your Grave (Staniel, #2)                                        | Avril Ashton                |            |               | 4.09           |
| Call the Coroner (Staniel, #1)                                      | Avril Ashton                |            |               | 4.07           |
| (Watch Me) Break You (Run This Town, #1)                            | Avril Ashton                |            |               | 4.05           |
| One for Sorrow (Magpie Rhyme, #1)                                   | Louise  Collins             | 036950089X | 9780369500892 | 4.24           |
| Pursuing the Egoist (Egoist, #2.5)                                  | Nero Seal                   |            |               | 4.05           |
| Psycho (Necessary Evils, #2)                                        | Onley James                 |            |               | 4.27           |
| Unhinged (Necessary Evils, #1)                                      | Onley James                 |            |               | 4.13           |
| Special Forces - Soldiers (Special Forces, #1)                      | Aleksandr Voinov            |            |               | 4.42           |
| Kill Game (Seven of Spades, #1)                                     | Cordelia Kingsbridge        | 1626496196 | 9781626496194 | 4.24           |
| Zero at the Bone (Zero at the Bone #1)                              | Jane Seville                | 1935192817 | 9781935192817 | 4.09           |
| How Did You Survive Without Us? (Irish Roulette, #1)                | Ki Brightly                 |            |               | 4.01           |
| In These Words, Volume 1                                            | Kichiku Neko                | 1569702756 | 9781569702758 | 4.25           |
| If the Seas Catch Fire                                              | L.A. Witt                   | 1943426112 | 9781943426119 | 4.10           |
| The Freshman                                                        | Louise  Collins             | 1773397982 |               | 3.96           |
| The Administration (The Administration, #1-9)                       | Manna Francis               |            |               | 4.55           |
| Houseboat on the Nile (Spy vs. Spook, #1)                           | Tinnean                     | 1613724128 | 9781613724125 | 3.92           |
| Pretty Pretty Boys (Hazard and Somerset, #1)                        | Gregory Ashe                | 1636210937 | 9781636210933 | 3.99           |
| Bitter Legacy (Bitter Legacy #1)                                    | Dal Maclean                 | 1935560433 |               | 4.28           |
| Between Ghosts                                                      | Garrett Leigh               | 1626493510 | 9781626493513 | 4.10           |
| ==Open Grave (DCI Jack Lambert, #1)==                               | A.M. Peacock                |            |               | 3.98           |
| Blue on Blue (Bitter Legacy, #3)                                    | Dal Maclean                 | 1935560689 | 9781935560685 | 4.41           |
| Object of Desire  (Bitter Legacy, #2)                               | Dal Maclean                 | 1935560549 | 9781935560548 | 4.16           |
| The Definitive Albert J. Sterne                                     | Julie Bozza                 |            |               | 4.07           |
| Father Figure                                                       | Kichiku Neko                |            |               | 3.85           |
| The Quaker (Duncan McCormack #1)                                    | Liam McIlvanney             | 1487003757 | 9781487003753 | 4.10           |
| Thrown Off the Ice                                                  | Taylor Fitzpatrick          |            | 9780463555668 | 4.45           |
| Ground Zero (Zero Hour, #1)                                         | Aimee Nicole Walker         |            |               | 4.09           |
| ==Drawn to You (Beyond the Cove, #1)==                              | Jaclyn Quinn                |            |               | 4.27           |
| ==Ollie Always==                                                    | John  Wiltshire             | 1608209997 | 9781608209996 | 4.16           |
| In From the Cold: The I Spy Stories (I Spy #1-3)                    | Josh Lanyon                 | 1937909352 | 9781937909352 | 4.17           |
| The Hate You Drink                                                  | N.R. Walker                 | 1925886506 | 9781925886504 | 4.04           |
| Return on Investment                                                | Aleksandr Voinov            |            |               | 4.09           |
| Provoked (Enlightenment, #1)                                        | Joanna Chambers             |            |               | 3.98           |
| Any Old Diamonds (Lilywhite Boys, #1)                               | K.J. Charles                |            | 9781912688074 | 4.29           |
| Best Man (Close Proximity, #1)                                      | Lily Morton                 |            |               | 4.12           |
| Risk Return (Return on Investment, #2)                              | Aleksandr Voinov            |            |               | 4.15           |
| Unhinge the Universe                                                | Aleksandr Voinov            | 194342618X |               | 4.18           |
| Evenfall (In the Company of Shadows, #1)                            | Ais                         |            |               | 4.19           |
| ==Barred Desires (The Deepest Desires #1)==                         | Ashley      James           |            |               | 3.81           |
| ==Charles (Learning to Love, #1)==                                  | Con Riley                   |            |               | 4.20           |
| ==Temporary Partner (Valor and Doyle Mysteries, #1)==               | Nicky James                 |            |               | 4.21           |
| A Million Little Moments (Inevitable #2)                            | Riley Hart                  |            |               | 4.14           |
| ==Latakia==                                                         | J.F.  Smith                 |            |               | 4.20           |
| ==**The Absolutist**==                                              | John Boyne                  |            |               | 4.10           |
| As Meat Loves Salt                                                  | Maria McCann                | 000655248X | 9780006552482 | 3.91           |
| A Scarecrow's Bible                                                 | Martin Hyatt                | 097634114X | 9780976341147 | 3.88           |
| The Last of the Wine                                                | Mary Renault                | 0375726810 | 9780375726811 | 4.05           |
| These Violent Delights                                              | Micah Nemerever             | 0062963635 | 9780062963635 | 3.97           |
| Waterline                                                           | Ross Raisin                 | 0670917354 | 9780670917358 | 3.85           |
| Protection                                                          | S.A. Reid                   | 147759339X | 9781477593394 | 3.90           |
| Narcissist                                                          | Suzi Slade                  |            |               | 4.33           |
| Bitter Eden                                                         | Tatamkhulu Afrika           | 1250043662 | 9781250043665 | 3.88           |
| Now and Then                                                        | William Corlett             | 0349107750 | 9780349107752 | 4.18           |
| Counterpunch (Belonging, #2)                                        | Aleksandr Voinov            | 1937058174 | 9781937058173 | 3.98           |
| Take My Picture                                                     | Giselle Ellis               | 1615813969 | 9781615813964 | 3.98           |
| The Free Boy                                                        | John  Shepherd              |            |               | 4.29           |
| He is Mine (Guns n' Boys, #2)                                       | K.A. Merikan                |            |               | 4.22           |
| Beyond Her Majesty's Men                                            | Marquesate                  |            |               | 3.94           |
| Her Majesty's Men                                                   | Marquesate                  | 0955988004 | 9780955988004 | 3.79           |
| Feat of Clay (Men of London #4)                                     | Susan Mac Nicol             |            |               | 4.01           |
| Triangle: The Complete Series (Triangle, #1-4)                      | Susann Julieva              |            | 9781476293110 | 4.08           |
| Young Mungo                                                         | Douglas   Stuart            | 0802159559 | 9780802159557 | 4.38           |
| Warrior's Cross                                                     | Madeleine Urban             | 1615810307 | 9781615810307 | 3.95           |
| The Backup Boyfriend (The Boyfriend Chronicles, #1)                 | River Jaymes                | 0991280709 |               | 3.93           |
| Boss's Son                                                          | Natasha Wallace             |            |               | 3.81           |
| Principles of Neural Science                                        | Eric R. Kandel              | 0838577016 | 9780838577011 | 4.48           |
| History Is All You Left Me                                          | Adam Silvera                | 1616956933 | 9781616956936 | 3.93           |
| Full Circle                                                         | Michael Thomas Ford         | 0758210574 | 9780758210579 | 4.15           |
| Ready to Catch Him Should He Fall                                   | Neil Bartlett               | 1852427051 | 9781852427054 | 3.71           |
| Bath Haus                                                           | P.J.  Vernon                | 0385546734 | 9780385546737 | 3.76           |
| The Sparsholt Affair                                                | Alan Hollinghurst           | 1447208218 | 9781447208211 | 3.54           |
| The Swimming-Pool Library                                           | Alan Hollinghurst           | 0679722564 | 9780679722564 | 3.73           |
| Loaded                                                              | Christos Tsiolkas           | 0099757710 | 9780099757719 | 3.63           |
| The Sluts                                                           | Dennis Cooper               | 0786716746 | 9780786716746 | 3.79           |
| The Married Man                                                     | Edmund White                | 0679781447 | 9780679781448 | 3.77           |
| Disorderly Men                                                      | Edward  Cahill              | 1531504442 | 9781531504441 | 4.31           |
| After the Blue Hour                                                 | John Rechy                  | 0802125891 | 9780802125897 | 3.28           |
| The New Life                                                        | Tom  Crewe                  | 1668000830 | 9781668000830 | 3.78           |
| That Which Wills                                                    | Alex Singer                 |            |               | 4.11           |
| The Dragon Tamer                                                    | Ana Bosch                   | 1613723156 | 9781613723159 | 3.50           |
| The Destroyers                                                      | Christopher Bollen          | 0062329987 | 9780062329981 | 3.39           |
| Chaos in my Wake                                                    | A.V. Shener                 | 9659299400 | 9789659299409 | 4.47           |
| Our Deadly Reunion (Unbreakable Ties, #1)                           | A.V. Shener                 |            |               | 4.60           |
| Hidden Scars (Darby U Hockey Boys, #1)                              | Andi Jaxon                  |            |               | 4.13           |
| ==The Handler (Manhandled #1)==                                     | August Jones                |            |               | 4.09           |
| My Policeman                                                        | Bethan Roberts              | 0701185848 | 9780701185848 | 4.01           |
| ==Junction X==                                                      | Erastes                     | 193769206X | 9781937692063 | 4.14           |
| ==Voice of Force==                                                  | G. Roger Denson             |            | 9781451568622 | 4.27           |
| Gone Girl                                                           | Gillian Flynn               |            |               | 4.14           |
| Map of the Harbor Islands                                           | J.G.  Hayes                 | 1560235969 | 9781560235965 | 4.38           |
| ==Secrets (Secrets, #1)==                                           | Julie Mannino               |            |               | 3.96           |
| The Magpie Lord (A Charm of Magpies, #1)                            | K.J. Charles                |            | 9780995799028 | 4.04           |
| If We Were Villains                                                 | M.L. Rio                    | 125009528X | 9781250095282 | 4.15           |
| Frog                                                                | Mary Calmes                 | 1613724691 | 9781613724699 | 4.17           |
| Skin Lane                                                           | Neil Bartlett               | 1852429194 | 9781852429195 | 4.06           |
| ==Skeletons in the Closet (Shadowy Solutions, #1)==                 | Nicky James                 |            |               | 4.28           |
| War Against the Animals                                             | Paul Russell                | 0312335393 | 9780312335397 | 3.98           |
| The Girl on the Train                                               | Paula Hawkins               | 1594633665 | 9781594633669 | 3.96           |
| Death Trick (Donald Strachey, #1)                                   | Richard Stevenson           | 1560234709 | 9781560234708 | 3.91           |
| Finding Zach (Finding Zach, #1)                                     | Rowan Speedwell             | 1615814469 | 9781615814466 | 3.95           |
| Tin Man                                                             | Sarah Winman                | 0755390962 | 9780755390960 | 3.97           |
| Forbidden Colors                                                    | Yukio Mishima               | 0375705163 | 9780375705168 | 3.92           |
| ==Blackout==                                                        | Marco Carocari              |            | 9781953789105 | 4.04           |
| The Death of Friends (Henry Rios Mystery, #5)                       | Michael Nava                | 1555838146 | 9781555838140 | 4.45           |
| Lies with Man (Henry Rios #3)                                       | Michael Nava                | 1612941974 | 9781612941974 | 4.46           |
| An Instance of the Fingerpost                                       | Iain Pears                  | 1573227951 | 9781573227957 | 3.94           |
| The Dove in the Belly                                               | Jim Grimsley                | 1646141318 | 9781646141319 | 4.18           |
| Tinker, Tailor, Soldier, Spy (George Smiley, #5; Karla Trilogy, #1) | John le Carré               |            |               | 4.06           |
| Battle Royale                                                       | Koushun Takami              | 156931778X | 9781569317785 | 4.26           |
| Pull Me Under                                                       | Zarah Detand                |            |               | 4.11           |
| ==Until You (Until, #1)==                                           | Briar Prescott              |            |               | 4.32           |
| ==Honeytrap==                                                       | Aster Glenn Gray            |            |               | 4.22           |
| Misfits (Urban Soul #1)                                             | Garrett Leigh               | 1916569072 | 9781916569072 | 4.15           |
| Shades of Henry (The Flophouse #1)                                  | Amy Lane                    |            |               | 4.11           |
| Chase in Shadow (Johnnies, #1)                                      | Amy Lane                    | 1613724217 | 9781613724217 | 4.12           |
| Taming the Beast (Tales from St. Giles #1)                          | Andrew  Grey                |            | 9781640800069 | 3.92           |
| Noble Intentions                                                    | Andrew  Grey                | 1635331234 | 9781635331233 | 3.69           |
| ==His Leading Man (Dreamspun Desires)==                             | Ashlyn Kane                 | 1641080043 | 9781641080040 | 3.72           |
| <mark style="background: #FFF3A3A6;">New Lease</mark>               | B.G. Thomas                 | 1635334284 | 9781635334289 | 3.69           |
| American Family: A Novel                                            | Catherine Marshall-Smith    | 1631521632 | 9781631521638 | 3.75           |
| Nights Like These                                                   | Chris Scully                | 1632164019 | 9781632164018 | 3.68           |
| Can't Hide from Me                                                  | Cordelia Kingsbridge        | 1626494436 | 9781626494435 | 3.83           |
| <mark style="background: #FFF3A3A6;">Ways and Means</mark>          | Daniel Lefferts             | 1419768190 | 9781419768194 | 3.88           |
| Red X                                                               | David Demchuk               | 0771025017 | 9780771025013 | 3.77           |
| Sticky Fingers                                                      | Davidson King               |            |               | 3.96           |
| The Foster Family                                                   | Jaime Samms                 | 1627985530 | 9781627985536 | 3.65           |
| Middlesex                                                           | Jeffrey Eugenides           | 0312422156 | 9780312422158 | 4.03           |
| Hide and Seek                                                       | Josh Lanyon                 |            |               | 4.01           |
| The Ghost Wore Yellow Socks (The Ghost Wore Yellow Socks, #1)       | Josh Lanyon                 |            | 9781596328105 | 3.95           |
| Puzzle for Two                                                      | Josh Lanyon                 |            | 9781649310279 | 3.81           |
| Torn Apart (Torn and Bound Duet, #1)                                | K. Webster                  |            |               | 4.13           |
| <mark style="background: #FFF3A3A6;">Waiting For You</mark>         | K.C. Wells                  | 1632160919 | 9781632160911 | 3.51           |
| Flash Rip                                                           | Keira Andrews               |            | 9781988260419 | 4.13           |
| Valor on the Move (Valor, #1)                                       | Keira Andrews               |            | 9780994092441 | 3.87           |
| Nothing but Good                                                    | Kess McKinley               | 1935560824 | 9781935560821 | 3.89           |
| What We Broke                                                       | Marley Valentine            |            |               | 4.24           |
| Kairos                                                              | Mary Calmes                 | 1644051974 | 9781644051979 | 3.86           |
| <mark style="background: #FFF3A3A6;">Still</mark>                   | Mary Calmes                 |            |               | 3.99           |
| Hummingbird Heartbreak (The Gold Brothers #1)                       | Max  Walker                 |            |               | 3.84           |
| Accepting the Fall                                                  | Meg Harding                 |            |               | 3.68           |
| Changing Tides                                                      | Michael Thomas Ford         | 0758210590 | 9780758210593 | 3.95           |
| A Hundred Thousand Words                                            | Nyrae Dawn                  |            |               | 4.09           |
| Hanging The Stars (Half Moon Bay #2)                                | Rhys Ford                   | 1634778987 | 9781634778985 | 4.05           |
| Tequila Mockingbird (Sinners #3)                                    | Rhys Ford                   |            |               | 4.26           |
| Wonderland                                                          | Rob Browatzke               |            |               | 3.24           |
| A Deeper Blue (Rules of Possession, #2)                             | S.E. Harmon                 |            | 9781640808089 | 4.16           |
| The Blueprint (Rules of Possession, #1)                             | S.E. Harmon                 |            | 9781640801783 | 3.86           |
| The Husband Hoax (Accidental Love, #1)                              | Saxon James                 |            |               | 4.05           |
| Southernmost                                                        | Silas House                 | 161620625X | 9781616206253 | 3.96           |
| Silver Fox (A Bridge to Abingdon, #4)                               | Tatum West                  |            |               | 4.26           |
| Commitment Issues                                                   | Wynn Wagner                 | 1615817034 | 9781615817030 | 3.71           |
| In Memoriam                                                         | Alice Winn                  | 0593534565 | 9780593534564 | 4.53           |
| Breaking Cover (Life Lessons, #2)                                   | Kaje Harper                 |            |               | 4.22           |
| Depth of Field (Last Chance, #1)                                    | Riley Hart                  |            |               | 4.08           |
