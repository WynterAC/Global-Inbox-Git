---
tag: Book
title: "Open Grave"
subtitle: "A Gripping Serial Killer Thriller"
author: [A.M. Peacock]
category: [Fiction]
publisher: Open Road Media
publish: 2018-09-26
total: 345
isbn: 1913682196 9781913682194
cover: http://books.google.com/books/content?id=_X88EAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:37:37
updated: 2024-08-15 13:37:37
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=_X88EAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Open Grave