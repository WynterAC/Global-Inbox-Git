---
tag: Book
title: "The Husband Hoax"
subtitle: ""
author: [Saxon James]
category: []
publisher: 
publish: 2023-08-30
total: 0
isbn: 1922741299 9781922741295
cover: 
localCover: 
status: unread
created: 2024-08-14 23:55:12
updated: 2024-08-14 23:55:12
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# The Husband Hoax