---
tag: Book
title: "Enemy of My Enemy"
subtitle: ""
author: [Tal Bauer]
category: []
publisher: Ninestar Press
publish: 2016-10-06
total: 
isbn: 1945952121 9781945952128
cover: http://books.google.com/books/content?id=REVQvgAACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:46:30
updated: 2024-08-15 13:46:30
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=REVQvgAACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Enemy of My Enemy