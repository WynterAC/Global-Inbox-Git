---
tag: Book
title: "Just a Bit Obsessed"
subtitle: ""
author: [Alessandra Hazard]
category: []
publisher: 
publish: 2019-09-06
total: 158
isbn: 1076328709 9781076328700
cover: 
localCover: 
status: unread
created: 2024-08-15 13:13:24
updated: 2024-08-15 13:13:24
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Just a Bit Obsessed