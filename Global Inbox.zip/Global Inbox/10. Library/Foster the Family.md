---
tag: Book
title: "Foster the Family"
subtitle: "Encouragement, Hope, and Practical Help for the Christian Foster Parent"
author: [Jamie C. Finn]
category: [Religion]
publisher: Baker Books
publish: 2022-02-15
total: 240
isbn: 149343442X 9781493434428
cover: http://books.google.com/books/content?id=G7Q5EAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 00:03:33
updated: 2024-08-15 00:03:33
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=G7Q5EAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Foster the Family