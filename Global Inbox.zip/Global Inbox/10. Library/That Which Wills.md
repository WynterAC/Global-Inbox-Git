---
tag: Book
title: "That Which Wills"
subtitle: "Virgo Rising"
author: [Alexandra Singer]
category: [Fiction]
publisher: 
publish: 2013-04-02
total: 
isbn: 0985319623 9780985319625
cover: 
localCover: 
status: unread
created: 2024-08-15 13:20:37
updated: 2024-08-15 13:20:37
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# That Which Wills