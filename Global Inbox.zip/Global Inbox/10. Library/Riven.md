---
tag: Book
title: "Riven"
subtitle: "A Novel"
author: [Roan Parrish]
category: [Fiction]
publisher: Loveswept
publish: 2018-05-29
total: 262
isbn: 1524799327 9781524799328
cover: http://books.google.com/books/content?id=zM0yDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 00:52:35
updated: 2024-08-15 00:52:35
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Riven