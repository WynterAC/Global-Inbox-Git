---
tag: Book
title: "A Scarecrow's Bible"
subtitle: ""
author: [Martin Hyatt]
category: [Drug addicts]
publisher: 
publish: 2006
total: 222
isbn:  STANFORD:36105122268050
cover: http://books.google.com/books/content?id=L6IgAQAAIAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:31:09
updated: 2024-08-15 13:31:09
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=L6IgAQAAIAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# A Scarecrow's Bible