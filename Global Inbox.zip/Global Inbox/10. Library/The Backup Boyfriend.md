---
tag: Book
title: "The Backup Boyfriend"
subtitle: "The Boyfriend Chronicles Book 1"
author: [River Jaymes]
category: [Divorced men]
publisher: 
publish: 2013-11-29
total: 275
isbn: 0991280717 9780991280711
cover: http://books.google.com/books/content?id=WadqngEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:24:21
updated: 2024-08-15 13:24:21
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=WadqngEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# The Backup Boyfriend