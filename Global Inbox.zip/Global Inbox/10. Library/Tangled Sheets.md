---
tag: Book
title: "Tangled Sheets"
subtitle: ""
author: [Michael Thomas Ford]
category: [Fiction]
publisher: Kensington Books
publish: 2005-01-01
total: 388
isbn: 0758208316 9780758208316
cover: http://books.google.com/books/content?id=XAr0YHzstx8C&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 00:51:19
updated: 2024-08-15 00:51:19
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=XAr0YHzstx8C&printsec=frontcover&img=1&zoom=1&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Tangled Sheets