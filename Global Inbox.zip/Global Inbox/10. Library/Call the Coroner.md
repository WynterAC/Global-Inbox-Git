---
tag: Book
title: "Call the Coroner"
subtitle: ""
author: [Avril Ashton]
category: [Fiction]
publisher: dead soft verlag
publish: 2023-03-16
total: 356
isbn: 3960895437 9783960895435
cover: http://books.google.com/books/content?id=R2-0EAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:44:15
updated: 2024-08-15 13:44:15
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=R2-0EAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Call the Coroner