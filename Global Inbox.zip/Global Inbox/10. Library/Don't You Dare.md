---
tag: Book
title: "Don't You Dare"
subtitle: ""
author: [Ce Ricci]
category: [Fiction]
publisher: 
publish: 2022-02-22
total: 0
isbn: 1960818015 9781960818010
cover: http://books.google.com/books/content?id=Weq5zwEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:56:30
updated: 2024-08-15 13:56:30
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=Weq5zwEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Don't You Dare