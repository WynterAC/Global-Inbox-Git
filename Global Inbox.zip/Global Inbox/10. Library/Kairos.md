---
tag: Book
title: "Kairos"
subtitle: ""
author: [Mary Calmes]
category: [Fiction]
publisher: Dreamspinner Press
publish: 2017-12-15
total: 137
isbn: 1640804978 9781640804975
cover: http://books.google.com/books/content?id=sAs_DwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-14 23:59:18
updated: 2024-08-14 23:59:18
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=sAs_DwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Kairos