---
tag: Book
title: "Why the Devil Stalks Death"
subtitle: ""
author: [L J Hayward]
category: []
publisher: 
publish: 2018-12-05
total: 348
isbn: 0994457197 9780994457196
cover: http://books.google.com/books/content?id=Oqr7zQEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:52:52
updated: 2024-08-15 13:52:52
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=Oqr7zQEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Why the Devil Stalks Death