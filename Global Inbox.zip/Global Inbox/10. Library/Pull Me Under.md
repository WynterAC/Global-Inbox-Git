---
tag: Book
title: "Pull Me Under"
subtitle: "A Football Romance"
author: [Zarah Detand]
category: []
publisher: 
publish: 2020-07-10
total: 416
isbn:  9798665224428
cover: http://books.google.com/books/content?id=3p7AzQEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 00:34:30
updated: 2024-08-15 00:34:30
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Pull Me Under