---
tag: Book
title: "Mind Fuck"
subtitle: ""
author: [Manna Francis]
category: [Fiction]
publisher: Casperian Books LLC
publish: 2007
total: 264
isbn: 1934081086 9781934081082
cover: http://books.google.com/books/content?id=XhY9CFYNkpQC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:39:09
updated: 2024-08-15 13:39:09
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=XhY9CFYNkpQC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Mind Fuck