---
tag: Book
title: "A Map of the Harbor Islands"
subtitle: ""
author: [Joseph George Hayes]
category: [Fiction]
publisher: Psychology Press
publish: 2006
total: 416
isbn: 1560235969 9781560235965
cover: http://books.google.com/books/content?id=0U0_4ZanjO4C&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 00:47:51
updated: 2024-08-15 00:47:51
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# A Map of the Harbor Islands