---
tag: Book
title: "Silver Fox"
subtitle: ""
author: [Tatum West]
category: [Fiction]
publisher: Bridge to Abingdon
publish: 2019-03-29
total: 300
isbn: 1092107517 9781092107518
cover: http://books.google.com/books/content?id=iwa3wwEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-14 23:54:33
updated: 2024-08-14 23:54:33
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=iwa3wwEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Silver Fox