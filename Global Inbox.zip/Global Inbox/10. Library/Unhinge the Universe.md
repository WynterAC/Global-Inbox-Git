---
tag: Book
title: "Unhinge the Universe"
subtitle: ""
author: [Aleksandr Voinov, L. A. Witt]
category: [Fiction]
publisher: Createspace Independent Publishing Platform
publish: 2016-07-15
total: 294
isbn: 1535144327 9781535144322
cover: http://books.google.com/books/content?id=NXbyvQAACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:28:24
updated: 2024-08-15 13:28:24
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=NXbyvQAACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Unhinge the Universe