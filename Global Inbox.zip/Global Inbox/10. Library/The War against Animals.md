---
tag: Book
title: "The War against Animals"
subtitle: ""
author: [Dinesh Wadiwel]
category: [Nature]
publisher: BRILL
publish: 2015-06-24
total: 314
isbn: 9004300422 9789004300422
cover: http://books.google.com/books/content?id=P5n8CQAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 00:45:10
updated: 2024-08-15 00:45:10
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=P5n8CQAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# The War against Animals