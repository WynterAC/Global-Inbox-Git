---
tag: Book
title: "Any Old Diamonds"
subtitle: ""
author: [Kj Charles]
category: []
publisher: Kjc Books
publish: 2019-01-30
total: 266
isbn: 1912688085 9781912688081
cover: http://books.google.com/books/content?id=CgRZwgEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:33:31
updated: 2024-08-15 13:33:31
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Any Old Diamonds