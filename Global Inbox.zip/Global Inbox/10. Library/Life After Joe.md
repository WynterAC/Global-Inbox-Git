---
tag: Book
title: "Life After Joe"
subtitle: ""
author: [Harper Fox]
category: [Fiction]
publisher: Carina Press
publish: 2010-05-26
total: 126
isbn: 1426890362 9781426890369
cover: http://books.google.com/books/content?id=L9Ndsfx87PMC&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 00:49:58
updated: 2024-08-15 00:49:58
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=L9Ndsfx87PMC&printsec=frontcover&img=1&zoom=1&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Life After Joe