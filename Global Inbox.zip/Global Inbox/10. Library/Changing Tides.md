---
tag: Book
title: "Changing Tides"
subtitle: ""
author: [Michael Thomas Ford]
category: [Fiction]
publisher: Kensington Books
publish: 2008-08-01
total: 368
isbn: 1496706803 9781496706805
cover: http://books.google.com/books/content?id=htgmCgAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-14 23:58:02
updated: 2024-08-14 23:58:02
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=htgmCgAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Changing Tides