---
tag: Book
title: "Waterline"
subtitle: ""
author: [Ross Raisin]
category: [Fiction]
publisher: Harper Collins
publish: 2012-02-07
total: 329
isbn: 1443409014 9781443409018
cover: http://books.google.com/books/content?id=s_hd38m7n9IC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:30:49
updated: 2024-08-15 13:30:49
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Waterline