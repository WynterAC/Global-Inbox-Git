---
tag: Book
title: "The Definitive Albert J. Sterne"
subtitle: ""
author: [Julie Bozza]
category: [Fiction]
publisher: LIBRAtiger
publish: 2019-04-16
total: 
isbn: 1925869121 9781925869125
cover: http://books.google.com/books/content?id=wlWQDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 01:13:28
updated: 2024-08-15 01:13:28
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# The Definitive Albert J. Sterne