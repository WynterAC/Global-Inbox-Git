---
tag: Book
title: "Breaking Cover"
subtitle: ""
author: [Kaje Harper]
category: [Gay police officers]
publisher: 
publish: 2011
total: 0
isbn: 160820409X 9781608204090
cover: http://books.google.com/books/content?id=nGyfXwAACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-14 23:51:35
updated: 2024-08-14 23:51:35
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Breaking Cover