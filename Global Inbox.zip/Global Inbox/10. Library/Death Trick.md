---
tag: Book
title: "Death Trick"
subtitle: ""
author: [Richard Stevenson]
category: [Fiction]
publisher: ManLove Romance Press
publish: 2009
total: 231
isbn: 1934531901 9781934531907
cover: http://books.google.com/books/content?id=LUGsSWflqZYC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 00:44:51
updated: 2024-08-15 00:44:51
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=LUGsSWflqZYC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Death Trick