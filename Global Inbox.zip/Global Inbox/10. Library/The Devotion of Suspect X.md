---
tag: Book
title: "The Devotion of Suspect X"
subtitle: "A Detective Galileo Novel"
author: [Keigo Higashino]
category: [Fiction]
publisher: Minotaur Books
publish: 2011-02-01
total: 305
isbn: 142999231X 9781429992312
cover: http://books.google.com/books/content?id=nKmmmYk_a34C&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:53:01
updated: 2024-08-15 13:53:01
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=nKmmmYk_a34C&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# The Devotion of Suspect X