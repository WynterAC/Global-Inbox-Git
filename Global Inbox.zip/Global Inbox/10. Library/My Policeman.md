---
tag: Book
title: "My Policeman"
subtitle: "NOW A MAJOR FILM STARRING HARRY STYLES"
author: [Bethan Roberts]
category: [Fiction]
publisher: Random House
publish: 2012-02-02
total: 356
isbn: 1448130980 9781448130986
cover: http://books.google.com/books/content?id=_ZFSNPOmKZgC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 00:48:58
updated: 2024-08-15 00:48:58
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# My Policeman