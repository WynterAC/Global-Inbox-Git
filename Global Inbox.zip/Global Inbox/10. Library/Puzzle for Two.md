---
tag: Book
title: "Puzzle for Two"
subtitle: ""
author: [Josh Lanyon]
category: [Fiction]
publisher: JustJoshin Publishing, Inc.
publish: 2023-05-28
total: 273
isbn: 1649310277 9781649310279
cover: http://books.google.com/books/content?id=uT7BEAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 00:02:40
updated: 2024-08-15 00:02:40
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=uT7BEAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Puzzle for Two