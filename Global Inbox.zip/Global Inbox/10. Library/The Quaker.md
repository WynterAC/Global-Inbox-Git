---
tag: Book
title: "The Quaker"
subtitle: "A Duncan McCormack Novel"
author: [Liam McIlvanney]
category: [Fiction]
publisher: House of Anansi
publish: 2018-07-24
total: 409
isbn: 1487003765 9781487003760
cover: http://books.google.com/books/content?id=KDplDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 01:13:40
updated: 2024-08-15 01:13:40
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=KDplDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# The Quaker