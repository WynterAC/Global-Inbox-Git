---
tag: Book
title: "A Single Man"
subtitle: "A Novel"
author: [Christopher Isherwood]
category: [Fiction]
publisher: Farrar, Straus and Giroux
publish: 2013-11-19
total: 192
isbn: 1466853344 9781466853348
cover: http://books.google.com/books/content?id=8X7WAAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:58:42
updated: 2024-08-15 13:58:42
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# A Single Man