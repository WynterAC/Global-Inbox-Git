---
tag: Book
title: "If This Gets Out"
subtitle: "A Novel"
author: [Sophie Gonzales, Cale Dietrich]
category: [Young Adult Fiction]
publisher: Wednesday Books
publish: 2021-12-07
total: 295
isbn: 1250805813 9781250805812
cover: http://books.google.com/books/content?id=TDMQEAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:57:23
updated: 2024-08-15 13:57:23
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# If This Gets Out