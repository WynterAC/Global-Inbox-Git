---
tags:
  - Book
title: Call Me by Your Name
subtitle: A Novel
author:
  - André Aciman
category:
  - Fiction
publisher: Farrar, Straus and Giroux
publish: 2008-01-22
total: 256
isbn: 0374707723 9780374707729
cover: http://books.google.com/books/content?id=ar4j52mEdLoC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-14 23:48:31
updated: 2024-08-14 23:48:31
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Call Me by Your Name