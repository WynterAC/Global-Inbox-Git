---
tag: Book
title: "Helping Hand"
subtitle: ""
author: [Jay Northcote]
category: []
publisher: CreateSpace
publish: 2015-07-13
total: 130
isbn: 1515032124 9781515032120
cover: http://books.google.com/books/content?id=5DUGswEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:56:45
updated: 2024-08-15 13:56:45
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=5DUGswEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Helping Hand