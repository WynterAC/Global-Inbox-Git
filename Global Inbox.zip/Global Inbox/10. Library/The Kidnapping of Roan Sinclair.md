---
tag: Book
title: "The Kidnapping of Roan Sinclair"
subtitle: ""
author: [Ashlyn Drewek]
category: []
publisher: 
publish: 2021-07
total: 
isbn: 1955211019 9781955211017
cover: http://books.google.com/books/content?id=-Sx6zgEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 01:11:01
updated: 2024-08-15 01:11:01
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=-Sx6zgEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# The Kidnapping of Roan Sinclair