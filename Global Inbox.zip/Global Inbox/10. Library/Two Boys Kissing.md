---
tag: Book
title: "Two Boys Kissing"
subtitle: ""
author: [David Levithan]
category: [Young Adult Fiction]
publisher: Knopf Books for Young Readers
publish: 2013-08-27
total: 210
isbn: 0307975649 9780307975645
cover: http://books.google.com/books/content?id=goMuk3rETagC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 00:52:50
updated: 2024-08-15 00:52:50
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=goMuk3rETagC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Two Boys Kissing