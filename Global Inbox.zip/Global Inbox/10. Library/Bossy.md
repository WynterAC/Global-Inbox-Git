---
tag: Book
title: "Bossy"
subtitle: ""
author: [N. R. Walker]
category: []
publisher: Blueheart Press
publish: 2021-03-04
total: 286
isbn: 192588662X 9781925886627
cover: http://books.google.com/books/content?id=-0o9zgEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:49:23
updated: 2024-08-15 13:49:23
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Bossy