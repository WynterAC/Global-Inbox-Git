---
tag: Book
title: "Dedicated"
subtitle: ""
author: [Neve Wilder]
category: [Fiction]
publisher: Wilder Press, LLC
publish: 2018-12-09
total: 339
isbn:  
cover: http://books.google.com/books/content?id=3nvqEAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 00:54:14
updated: 2024-08-15 00:54:14
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=3nvqEAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Dedicated