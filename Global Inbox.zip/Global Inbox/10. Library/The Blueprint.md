---
tag: Book
title: "The Blueprint"
subtitle: ""
author: [S. E. Harmon]
category: [Fiction]
publisher: 
publish: 2019-03-19
total: 0
isbn: 1641080477 9781641080477
cover: http://books.google.com/books/content?id=uncntQEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-14 23:57:45
updated: 2024-08-14 23:57:45
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=uncntQEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# The Blueprint