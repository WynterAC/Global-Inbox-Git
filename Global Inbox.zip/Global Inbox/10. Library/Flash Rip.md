---
tag: Book
title: "Flash Rip"
subtitle: "Gay Romance"
author: [Keira Andrews]
category: [Fiction]
publisher: Keira Andrews
publish: 2019-12-30
total: 299
isbn: 1988260418 9781988260419
cover: http://books.google.com/books/content?id=AVTHDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 00:00:09
updated: 2024-08-15 00:00:09
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Flash Rip