---
tag: Book
title: "Houseboat on the Nile"
subtitle: ""
author: [Tinnean]
category: [Fiction]
publisher: JMS Books LLC
publish: 2019-12-11
total: 487
isbn: 0463160584 9780463160589
cover: http://books.google.com/books/content?id=J2nDDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:38:46
updated: 2024-08-15 13:38:46
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=J2nDDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Houseboat on the Nile