---
tag: Book
title: "Borrowing Blue"
subtitle: "Made Marian Band 1"
author: [Lucy Lennox]
category: []
publisher: 
publish: 2020
total: 
isbn: 3960893787 9783960893783
cover: 
localCover: 
status: unread
created: 2024-08-15 13:52:44
updated: 2024-08-15 13:52:44
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Borrowing Blue