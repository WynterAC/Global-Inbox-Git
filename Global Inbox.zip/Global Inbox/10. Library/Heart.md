---
tag: Book
title: "Heart"
subtitle: ""
author: [Garrett Leigh]
category: []
publisher: 
publish: 2019-07-20
total: 212
isbn: 1913220060 9781913220068
cover: http://books.google.com/books/content?id=vNy8xwEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 01:09:24
updated: 2024-08-15 01:09:24
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=vNy8xwEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Heart