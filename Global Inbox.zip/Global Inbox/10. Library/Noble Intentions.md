---
tag: Book
title: "Noble Intentions"
subtitle: ""
author: [Andrew Grey]
category: [Gay men]
publisher: Dreamspinner Press LLC
publish: 2016-12-12
total: 0
isbn: 1635331226 9781635331226
cover: http://books.google.com/books/content?id=L3UeMQAACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 00:29:51
updated: 2024-08-15 00:29:51
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=L3UeMQAACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Noble Intentions