---
tag: Book
title: "Shades of Henry"
subtitle: ""
author: [Amy Lane]
category: [Fiction]
publisher: Dreamspinner Press
publish: 2020-03-31
total: 264
isbn: 1644056186 9781644056189
cover: http://books.google.com/books/content?id=jevBDwAAQBAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 00:30:39
updated: 2024-08-15 00:30:39
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=jevBDwAAQBAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Shades of Henry