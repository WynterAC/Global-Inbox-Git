---
tag: Book
title: "Latakia"
subtitle: ""
author: [J. F. Smith]
category: []
publisher: 
publish: 2011-12-04
total: 314
isbn: 1974443876 9781974443871
cover: http://books.google.com/books/content?id=2Q5bswEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:31:28
updated: 2024-08-15 13:31:28
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Latakia