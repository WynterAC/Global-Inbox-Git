---
tag: Book
title: "Cut & Run"
subtitle: ""
author: [Abigail Roux]
category: [Fiction]
publisher: Riptide Publishing
publish: 2024-06-10
total: 240
isbn: 1963773012 9781963773019
cover: http://books.google.com/books/content?id=vw4LEQAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:40:44
updated: 2024-08-15 13:40:44
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=vw4LEQAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Cut & Run