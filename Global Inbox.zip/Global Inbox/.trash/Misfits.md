---
tag: Book
title: "Misfits"
subtitle: "A Personal Manifesto"
author: [Michaela Coel]
category: [Self-Help]
publisher: Henry Holt and Company
publish: 2021-09-07
total: 74
isbn: 1250843456 9781250843456
cover: http://books.google.com/books/content?id=TJgpEAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 00:31:09
updated: 2024-08-15 00:31:09
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=TJgpEAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Misfits