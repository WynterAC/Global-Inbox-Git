---
tag: Book
title: "Tangled Sheets"
subtitle: ""
author: [Jo Leigh]
category: [Fiction]
publisher: Harlequin
publish: 2011-07-15
total: 224
isbn: 1459257480 9781459257481
cover: http://books.google.com/books/content?id=sTapoORef8QC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 00:50:28
updated: 2024-08-15 00:50:28
---

%% To use an image URL from the server, use the following syntax: %%


%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# Tangled Sheets