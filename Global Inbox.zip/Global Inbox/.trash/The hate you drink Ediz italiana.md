---
tag: Book
title: "The hate you drink. Ediz. italiana"
subtitle: ""
author: [N. R. Walker]
category: [Fiction]
publisher: 
publish: 2022
total: 
isbn:  9791220702713
cover: http://books.google.com/books/content?id=Oq0nzwEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
localCover: 
status: unread
created: 2024-08-15 13:34:03
updated: 2024-08-15 13:34:03
---

%% To use an image URL from the server, use the following syntax: %%
![cover|150](http://books.google.com/books/content?id=Oq0nzwEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api)

%% To save images locally, enable the 'Enable Cover Image Save' option in the settings and enter as follows: %%


# The hate you drink. Ediz. italiana