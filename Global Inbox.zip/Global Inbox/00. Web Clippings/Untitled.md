---
created: 2024-08-18 03:42:30
---
`source: query`
`query: "<% tp.file.folder(true) %>"`
`minFontSize: 5`
`weight: 3`
`shuffle: true`
